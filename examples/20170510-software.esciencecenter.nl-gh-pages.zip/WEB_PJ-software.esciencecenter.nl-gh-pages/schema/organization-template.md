---
authorOfReport: array
involvedIn: array
linkedInUrl: string
logo: string
name: string
organizationOf: array
ownerOf: array
researchgateUrl: string
tagLine: string
twitterUrl: string
userOf: array
website: string
---
Type your MarkDown description of the organization here
