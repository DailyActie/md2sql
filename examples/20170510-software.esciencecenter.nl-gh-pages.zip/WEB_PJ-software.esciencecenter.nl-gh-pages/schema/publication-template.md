---
author: array
date: string
doi: string
endorsedBy: array
publishedIn: string
type: string
---
Type your MarkDown description of the publication here
