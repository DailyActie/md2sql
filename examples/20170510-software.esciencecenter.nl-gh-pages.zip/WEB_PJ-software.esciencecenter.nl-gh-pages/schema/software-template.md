---
badges: array, see /schema/software
codeRepository: string
competence: array, see /schema/software
contactPerson: a person e.g. /person/s.verhoeven
contributingOrganization: array, see /schema/software
contributor: array, see /schema/software
dependency: array, see /schema/software
dependencyOf: array, see /schema/software
discipline: array, see /schema/software
documentationUrl: string
doi: string
downloadUrl: string
endorsedBy: array, see /schema/software
expertise: array, see /schema/software
involvedOrganization: array, see /schema/software
license: array, see /schema/software
logo: string
name: string
nlescWebsite: string
owner: array, see /schema/software
programmingLanguage: array, see /schema/software
startDate: string
status: string
supportLevel: string
tagLine: string
technologyTag: array, see /schema/software
type: string
usedIn: array, see /schema/software
user: array, see /schema/software
website: string
---
Type your MarkDown description of the software here
