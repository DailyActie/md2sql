---
competence: array
contactPerson: a person
coordinator: a person
dataFormat: array
dataMagnitude: string
discipline: array
endDate: string
endorsedBy: array
engineer: array
expertise: array
infrastructure: string
involvedOrganization: array
logo: string
name: string
nlescWebsite: string
principalInvestigator: array
publication: array
startDate: string
tagLine: string
uses: array
website: string
---
Type your MarkDown description of the project here
