---
name: PyROOT
tagLine: A Python extension module that allows the user to interact with any ROOT class from the Python interpreter.
programmingLanguage:
- C++, Python
competence:
- Big Data Analytics
discipline:
- Physics & Beyond
expertise:
- Data Assimilation
supportLevel: specialized
contributingOrganization:
- /organization/nikhef
user:
- /organization/nikhef
involvedOrganization:
- /organization/nikhef
usedIn:
- /project/pandas-root
dependency:
- ROOT
---
PyROOT is a Python extension module that allows the user to interact with any ROOT class from the Python interpreter.
