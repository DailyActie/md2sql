---
name: Gaudi
tagLine: A Software Architecture and Framework for building HEP Data Processing Applications.
programmingLanguage:
- C++
discipline:
- eScience Methodology
contributingOrganization:
- /organization/nikhef
user:
- /organization/nikhef
involvedOrganization:
- /organization/nikhef
---
The Toolkit for Data Modeling with ROOT allows for modeling probability distributions in a compact and abstract way. 