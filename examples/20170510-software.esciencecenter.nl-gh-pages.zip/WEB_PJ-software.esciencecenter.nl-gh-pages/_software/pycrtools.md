---
name: PyCRTools
tagLine: Python wrapper around CR-Tools
contributingOrganization:
- /organization/astron
- /organization/radboud.university.nijmegen
contributor:
- name: M. Vandenakker
  affiliation:
  - /organization/astron
discipline:
- Physics & Beyond
programmingLanguage:
- Python
dependency:
- /software/cr-tools
website: http://www.astro.ru.nl/software/pycrtools
---
Python wrapper around CR-Tools.
