---
name: CR-Tools
contactPerson:
tagLine: Reduction of Cosmic Ray data.
contributingOrganization:
- /organization/astron
contributor:
- name: L. Bähren
  affiliation:
  - /organization/astron
discipline:
- Physics & Beyond
programmingLanguage:
- C++
dependencyOf:
- /software/pycrtools
website: http://www.lofar.org/wiki/doku.php?id=public:user_software:cr-tools
---
Reduction of Cosmic Ray data.
