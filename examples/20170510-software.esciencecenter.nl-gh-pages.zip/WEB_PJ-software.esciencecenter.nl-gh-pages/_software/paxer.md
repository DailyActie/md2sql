---
name: PAX
tagLine: Processor for Analyzing XENON (PAX) is used for doing digital signal processing and other data processing on the XENON100/XENON1T raw data.
programmingLanguage:
- Python
discipline:
- Physics & Beyond
expertise:
- Handling Sensor Data
contributingOrganization:
- /organization/nikhef
user:
- /organization/nikhef
involvedOrganization:
- /organization/nikhef
---
 Processor for Analyzing XENON (PAX) is used for doing digital signal processing and other data processing on the XENON100/XENON1T raw data.