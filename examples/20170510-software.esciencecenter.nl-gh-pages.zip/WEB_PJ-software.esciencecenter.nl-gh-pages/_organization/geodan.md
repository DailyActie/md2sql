---
involvedIn:
- /project/3d-geospatial-data-exploration-for-modern-risk-management-systems
- /project/big-data-analytics-in-the-geo-spatial-domain
logo: /images/organization/geodan.gif
name: Geodan
tagLine: Geodan
website: http://www.geodan.com
---
Geodan
