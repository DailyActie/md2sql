---
involvedIn:
- /project/automated-parallel-calculation-of-collaborative-statistical-models
- /project/pandas-root
- /project/neutrino
logo: /images/organization/nikhef.jpg
name: NIKHEF
tagLine: National Institute for Subatomic Physics
userOf:
- /software/root-conda-recipes
- /software/root
- /software/pyroot
- /software/gaudi
- /software/mcatnlo
- /software/roofit
- /software/paxer
website: http://www.nikhef.nl/
---
Nikhef is the National Institute for Subatomic Physics. Our research is aimed at particle and astroparticle physics.
