---
involvedIn:
- /project/3d-geospatial-data-exploration-for-modern-risk-management-systems
logo: /images/organization/commit.png
name: COMMIT
tagLine: COMMIT A Public-private ICT research community
website: http://www.commit-nl.nl/
---
COMMIT
