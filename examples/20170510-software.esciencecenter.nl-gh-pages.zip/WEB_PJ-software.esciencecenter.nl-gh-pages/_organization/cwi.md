---
involvedIn:
- /project/generic-escience-technologies
- /project/3d-geospatial-data-exploration-for-modern-risk-management-systems
- /project/big-data-analytics-in-the-geo-spatial-domain
- /project/massive-point-clouds-for-esciences
- /project/compressing-the-sky-into-a-large-collection-of-statistical-models
- /project/towards-large-scale-cloud-resolving-climate-simulations
logo: /images/organization/cwi.png
name: CWI
tagLine: Centrum Wiskunde & Informatica
website: http://www.cwi.nl/
---
CWI is the national research institute for mathematics and computer science in the Netherlands and is an institute of the Netherlands Organisation for Scientific Research (NWO). The institute was founded in 1946 and is located at Amsterdam Science Park.
