---
involvedIn:
- /project/massive-point-clouds-for-esciences
logo: /images/organization/rijkswaterstaat.png
name: Rijkswaterstaat
tagLine: Rijkswaterstaat
website: http://www.rijkswaterstaat.nl/
---
Rijkswaterstaat is responsible for the design, construction, management and maintenance of the main infrastructure facilities in the Netherlands. This includes the main road network, the main waterway network and watersystems.
