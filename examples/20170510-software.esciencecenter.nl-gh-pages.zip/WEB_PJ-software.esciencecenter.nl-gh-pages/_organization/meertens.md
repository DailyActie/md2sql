---
involvedIn:
- /project/from-sentiment-mining-to-mining-embodied-emotions
logo: /images/organization/meertens.png
name: Meertens Institute
website: http://www.meertens.knaw.nl
---
The Meertens Institute, established in 1926, has been a research institute of the Royal Netherlands Academy of Arts and Sciences (KNAW) since 1952. We study the diversity in language and culture in the Netherlands.
