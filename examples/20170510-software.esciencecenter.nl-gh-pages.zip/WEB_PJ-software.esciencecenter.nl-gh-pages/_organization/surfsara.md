---
involvedIn:
- /project/twinl
- /software/twiqs.nl
- /project/texcavator
- /project/pidimehs
- /project/esibayes
logo: /images/organization/surfsara.png
name: SURFsara
ownerOf:
- /software/twiqs.nl
- /software/picas
website: https://www.surf.nl/en/about-surf/subsidiaries/surfsara/
---
SURFsara creates a bridge between research and advanced ICT. We do so with a passion for scientific research in our DNA and with extensive expertise contained in our high-performance infrastructure. This enables us to facilitate scientific research and develop initiatives for the business community.
