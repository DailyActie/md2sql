---
involvedIn:
- /project/large-scale-data-assimilation
- /project/ewatercycle
- /project/microscopy
- /project/massive-point-clouds-for-esciences
- /project/big-data-analytics-in-the-geo-spatial-domain
logo: /images/organization/tu-delft.png
name: Delft University of Technology
website: http://www.tudelft.nl
---
TU Delft cooperates with many other educational and research institutions, both in the Netherlands and abroad. The high quality of our research and teaching is renowned. TU Delft has numerous contacts with governments, trade associations, consultancies, industry and small and medium-sized companies.
