---
involvedIn:
- /project/idark
logo: /images/organization/upv.png
name: "Universitat Polit\xE8cnica de Val\xE8ncia"
website: http://www.upv.es
---

