---
logo: /images/organization/ntu.gif
name: Nanyang Technical University
website: http://www.ntu.edu.sg
---
Young and research-intensive, Nanyang Technological University (NTU Singapore) is ranked 13th globally. It is also placed 1st amongst the world’s best young universities.

The university has colleges of Engineering, Business, Science, Humanities, Arts, & Social Sciences, and an Interdisciplinary Graduate School. It also has a medical school, Lee Kong Chian School of Medicine, set up jointly with Imperial College London.
