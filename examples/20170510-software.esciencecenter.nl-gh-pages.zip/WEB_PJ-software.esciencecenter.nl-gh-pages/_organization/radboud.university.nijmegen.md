---
involvedIn:
- /software/twiqs.nl
- /project/twinl
- /project/idark
- /project/viaappia-patty
- /project/biomarker
- /project/3d-e-chem
logo: /images/organization/radboud.university.nijmegen.png
name: Radboud University Nijmegen
ownerOf:
- /software/twiqs.nl
- /software/3d-e-chem-vm
- /software/knime-archetype
- /software/chemical-analytics-platform
- /software/knime-gpcrdb
- /software/knime-klifs
- /software/knime-molviewer
website: http://www.ru.nl/
---
Radboud University is a broad, international oriented university that aspires to be one of the best in Europe. Together with Radboudumc, we have created an intellectual environment that inspires and challenges our students and staff so that  they can extend the scope of academic disciplines and benefit society.
