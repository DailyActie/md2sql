---
linkedInUrl: https://www.linkedin.com/company/tno
logo: /images/organization/tno.jpg
name: TNO
ownerOf:
- /software/common-sense
researchgateUrl: https://www.researchgate.net/institution/TNO
tagLine: Nederlandse organisatie voor Toegepast-Natuurwetenschappelijk Onderzoek
userOf:
- /software/common-sense
website: http://www.tno.nl/
---

