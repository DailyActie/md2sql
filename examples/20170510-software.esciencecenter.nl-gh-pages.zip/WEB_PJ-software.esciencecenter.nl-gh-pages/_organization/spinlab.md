---
involvedIn:
- /project/viaappia-patty
logo: /images/organization/spinlab.jpg
name: SPINlab
website: https://spinlab.vu.nl
---
The Spatial Information Laboratory (SPINlab) is the centre for research and education in Geo-Information Science at VU University Amsterdam.

The mission of the SPINLab is to develop an internationally recognised research and education portfolio in the areas of Geo-Information Science and Technology. The lab is part of the Department of Spatial Economics and is chaired by Prof.dr. Henk J. Scholten.
