---
involvedIn:
- /software/recipy
logo: /images/organization/university.of.southampton.svg
name: University of Southampton
website: http://www.southampton.ac.uk/
---
The University of Southampton is a world-class university built on the quality and diversity of our community. Our staff place a high value on excellence and creativity, supporting independence of thought, and the freedom to challenge existing knowledge and beliefs through critical research and scholarship. Through our education and research we transform people’s lives and change the world for the better.
