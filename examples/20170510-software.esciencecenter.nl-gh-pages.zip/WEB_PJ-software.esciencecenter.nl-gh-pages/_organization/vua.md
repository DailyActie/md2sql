---
involvedIn:
- /project/generic-escience-technologies
- /project/computational-chemistry-made-easy
- /project/enhancing-protein-drug-binding-prediction
- /project/from-sentiment-mining-to-mining-embodied-emotions
- /project/visualizing-uncertainty-and-perspectives
- /project/big-data-analytics-in-the-geo-spatial-domain
- /project/viaappia-patty
- /project/a-jungle-computing-approach-to-large-scale-online-forensic-analysis
- /project/3d-e-chem
- /project/dive-plus
- /project/drwatson
linkedInUrl: https://www.linkedin.com/company/vrije-universiteit-amsterdam
logo: /images/organization/vua.png
name: VU University Amsterdam
organizationOf:
- /software/heem-dataset
ownerOf:
- /software/heem-dataset
- /software/3d-e-chem-vm
- /software/knime-archetype
- /software/chemical-analytics-platform
- /software/knime-gpcrdb
- /software/knime-klifs
- /software/knime-molviewer
researchgateUrl: https://www.researchgate.net/institution/VU_University_Amsterdam
tagLine: VU University Amsterdam
twitterUrl: https://twitter.com/vuamsterdam
userOf:
- /software/noodles
website: http://www.vu.nl/
---
