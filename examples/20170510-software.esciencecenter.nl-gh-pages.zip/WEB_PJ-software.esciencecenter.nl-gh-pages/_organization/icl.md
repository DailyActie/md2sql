---
involvedIn:
- /project/idark
logo: /images/organization/icl.jpg
name: Imperial College London
website: http://www.imperial.ac.uk
---

