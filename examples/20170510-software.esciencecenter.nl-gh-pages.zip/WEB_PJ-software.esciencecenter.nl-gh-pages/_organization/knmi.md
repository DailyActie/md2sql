---
name: Koninklijk Nederlands Meteorologisch Instituut
website: http://www.knmi.nl/
tagLine: Koninklijk Nederlands Meteorologisch Instituut
logo: /images/organization/knmi.png
involvedIn:
- /project/primavera
- /project/towards-large-scale-cloud-resolving-climate-simulations
userOf:
- /software/openifs
- /software/cdo
---
The Royal Netherlands Meteorological Institute (KNMI) is the Dutch national weather service. Primary tasks of KNMI are weather forecasting, and monitoring of weather, climate, air quality and seismic activity. KNMI is also the national research and information centre for meteorology, climate, air quality, and seismology.
