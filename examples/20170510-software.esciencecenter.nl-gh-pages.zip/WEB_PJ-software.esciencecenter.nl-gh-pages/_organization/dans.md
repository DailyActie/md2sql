---
authorOfReport:
- /report/software-sustainability
linkedInUrl: https://www.linkedin.com/company/dans
logo: /images/organization/dans.jpg
name: Data Archiving and Networked Services (DANS)
website: http://www.dans.knaw.nl
---
DANS bevordert duurzame toegang tot digitale onderzoeksgegevens en stimuleert dat onderzoekers gegevens duurzaam archiveren en hergebruiken.
