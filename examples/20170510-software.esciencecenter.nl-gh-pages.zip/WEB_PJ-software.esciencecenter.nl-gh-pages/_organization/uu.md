---
involvedIn:
- /project/texcavator
- /project/ewatercycle
- /project/abcmuse
- /project/shico
logo: /images/organization/uu.svg
name: Utrecht University
ownerOf:
- /software/texcavator
userOf:
- /software/texcavator
website: http://www.uu.nl
---
Utrecht University is an international research university of the highest
quality and the alma mater of many leading names, academics and scientists who
have made an important contribution to the quality of society.
