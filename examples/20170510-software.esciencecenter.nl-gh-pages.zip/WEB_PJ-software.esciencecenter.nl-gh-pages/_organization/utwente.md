---
involvedIn:
- /project/what-works-when-for-whom
- /project/improving-photogrammetry
logo: /images/organization/utwente.png
name: University of Twente
website: https://www.utwente.nl/
---
The University of Twente is a modern, entrepreneurial university, leading in the area of new technologies and a catalyst for change, innovation and progress in society. Our strength lies in our capacity to combine. After all, the most interesting and relevant innovations take place at the cutting edge of technologies and their impact on humanity and societies.
