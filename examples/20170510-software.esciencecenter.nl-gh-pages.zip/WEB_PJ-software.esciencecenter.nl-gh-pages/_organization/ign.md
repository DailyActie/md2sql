---
involvedIn:
- /project/improving-photogrammetry
logo: /images/organization/ign.jpg
name: "Institut national de l\u2019information g\xE9ographique et foresti\xE8re"
ownerOf:
- /software/micmac
website: http://www.ign.fr/
---

