---
involvedIn:
- /project/beyond-the-data-explosion
- /project/error-detection-and-error-localization
- /project/aa-alert
logo: /images/organization/astron.gif
name: ASTRON
ownerOf:
- /software/casacore
tagLine: Netherlands Institute for Radio Astronomy
userOf:
- /software/casacore
website: http://www.astron.nl/
---
ASTRON is the Netherlands Institute for Radio Astronomy. Its mission
is to make discoveries in radio astronomy happen, via the development
of novel and innovative technologies, the operation of world-class
radio astronomy facilities, and the pursuit of fundamental
astronomical research.
