---
involvedIn:
- /project/pidimehs
- /project/viaappia-patty
logo: /images/organization/university.of.groningen.png
name: University of Groningen
tagLine: University of Groningen
userOf:
- /software/pidilib
website: http://www.rug.nl/
---
University of Groningen.
