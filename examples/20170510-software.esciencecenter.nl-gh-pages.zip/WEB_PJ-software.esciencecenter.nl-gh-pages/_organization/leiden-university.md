---
involvedIn:
- /project/amuse
- /project/abcmuse
- /project/neutrino
linkedInUrl: https://www.linkedin.com/company/leiden-university
logo: /images/organization/leiden-university.png
name: Leiden University
ownerOf:
- /software/amuse
researchgateUrl: https://www.researchgate.net/institution/Leiden_University
tagLine: Leiden University
twitterUrl: https://twitter.com/UniLeidenNews
website: https://www.universiteitleiden.nl/en/
---
Leiden University was founded in 1575 and is one of Europe’s leading international research universities. It has seven faculties in the arts, sciences and social sciences, spread over locations in Leiden and The Hague. The University has over 5,500 staff members and 25,800 students. The motto of the University is 'Praesidium Libertatis' - Bastion of Freedom.
