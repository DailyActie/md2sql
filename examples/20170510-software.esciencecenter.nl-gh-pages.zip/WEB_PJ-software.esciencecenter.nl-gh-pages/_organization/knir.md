---
involvedIn:
- /project/hadrianus
- /project/viaappia-patty
logo: /images/organization/knir.png
name: Koninklijk Nederlands Instituut in Rome
tagLine: Koninklijk Nederlands Instituut in Rome
website: http://www.knir.it/
---
Koninklijk Nederlands Instituut in Rome
