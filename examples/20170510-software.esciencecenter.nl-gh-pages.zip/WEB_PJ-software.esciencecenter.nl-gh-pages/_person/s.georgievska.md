---
affiliation:
- /organization/nlesc
contactPersonOf:
- /project/arena
- /software/cclustera
- /project/massive-biological-data-clustering-reporting-and-visualization-tools
contributorOf:
- /software/cclustera
email: s.georgievska@esciencecenter.nl
engineerOf:
- /software/cclustera
- /project/arena
endorsedBy:
- /organization/nlesc
jobTitle: eScience Research Engineer
name: Sonja Georgievska
nlescWebsite: https://www.esciencecenter.nl/profile/dr.-sonja-georgievska
photo: /images/person/s.georgievska.jpg
---
