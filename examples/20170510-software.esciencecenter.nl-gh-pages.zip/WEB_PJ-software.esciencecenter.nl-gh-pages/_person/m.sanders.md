---
affiliation:
- /organization/nlesc
contributorOf:
- /software/magma
name: Marijn Sanders
endorsedBy:
- /organization/nlesc
userOf:
- /software/magma
---

