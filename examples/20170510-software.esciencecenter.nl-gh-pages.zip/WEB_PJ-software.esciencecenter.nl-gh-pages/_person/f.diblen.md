---
affiliation:
- http://sofware.esciencecenter.nl/organization/nlesc
contactPersonOf:
- /project/idark
contributorOf:
- /software/spiraljs
- /software/metrochartjs
- /software/punchcardjs
email: f.diblen@esciencecenter.nl
endorsedBy:
- /organization/nlesc
engineerOf:
- /project/idark
jobTitle: eScience Research Engineer
name: Faruk Diblen
---

