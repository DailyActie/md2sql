---
competence:
- Efficient Computing
contactPerson: /person/r.vannieuwpoort
coordinator: /person/r.vannieuwpoort
discipline:
- Life Sciences & eHealth
engineer:
- /person/e.ranguelova
expertise:
- Distributed Computing
endorsedBy:
- /organization/nlesc
involvedOrganization:
- /organization/radboud.university.nijmegen
- /organization/nlesc
logo: /images/project/biomarker.jpg
name: biomarker
nlescWebsite: https://www.esciencecenter.nl/project/biomarker-boosting
uses:
- /software/xenon
---
Better biomarkers through datasharing.
Developing tools and services to combine datasets obtained by different medical centers.
