---
contactPerson: /person/j.maassen
coordinator: /person/j.maassen
endorsedBy:
- /organization/nlesc
logo: /images/project/esalsa.jpg
name: eSalsa
uses:
- /software/xenon
- /software/magnesium
---

