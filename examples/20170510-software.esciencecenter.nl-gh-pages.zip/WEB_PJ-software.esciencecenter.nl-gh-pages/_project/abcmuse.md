---
competence:
- Efficient Computing
contactPerson: /person/j.maassen
coordinator: /person/j.maassen
discipline:
- Physics & Beyond
expertise:
- Distributed Computing
endorsedBy:
- /organization/nlesc
involvedOrganization:
- /organization/uu
- /organization/leiden-university
logo: /images/project/abcmuse.jpg
name: ABCmuse
nlescWebsite: https://www.esciencecenter.nl/project/abc-muse
uses:
- /software/xenon
- /software/amuse
---
Robust high-resolution multi-physics simulations.
