---
competence:
- Efficient Computing
- Optimized Data Handling
contactPerson: /person/f.diblen
coordinator: /person/r.bakhshi
discipline:
- Physics & Beyond
- eScience Methodology
endDate: 2019-04-01
engineer:
- /person/f.diblen
expertise:
- Accelerated Computing
- Information Visualization
endorsedBy:
- /organization/nlesc
involvedOrganization:
- /organization/nlesc
- /organization/radboud.university.nijmegen
- /organization/uva
- /organization/upv
- /organization/icl
logo: /images/project/idark.jpg
name: iDark
nlescWebsite: http://www.esciencecenter.nl/project/idark
principalInvestigator:
- affiliation:
  - /organization/radboud.university.nijmegen
  name: Dr. Sascha Caron
  website: http://www.nikhef.nl/~scaron
startDate: 2016-04-01
tagLine: Project combines the worldwide data within the most general models of Dark
  Matter.
---
