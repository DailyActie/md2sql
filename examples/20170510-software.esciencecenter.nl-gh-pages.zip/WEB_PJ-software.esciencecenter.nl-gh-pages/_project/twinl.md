---
competence:
- Big Data Analytics
contactPerson: /person/e.tjongkimsang
dataFormat:
- CSV
- JSON
dataMagnitude: TB
discipline:
- Humanities & Social Sciences
endDate: 2015-09-01
engineer:
- /person/e.tjongkimsang
expertise:
- Text Mining
- Information Retrieval
endorsedBy:
- /organization/nlesc
infrastructure: Cloud for data ingestion and retrieval, Hadoop for indexing and searching
involvedOrganization:
- /organization/nlesc
- /organization/radboud.university.nijmegen
- /organization/surfsara
logo: /images/project/twinl.jpg
name: TwiNL
nlescWebsite: https://www.esciencecenter.nl/project/twinl
principalInvestigator:
- affiliation:
  - /organization/radboud.university.nijmegen
  name: Prof. Antal van den Bosch
  website: http://antalvandenbosch.ruhosting.nl/
startDate: 2013-02-01
tagLine: Analysis of social media messages
uses:
- /software/twiqs.nl
---
Developing a centralized service for gathering, storing, and analyzing Twitter messages
