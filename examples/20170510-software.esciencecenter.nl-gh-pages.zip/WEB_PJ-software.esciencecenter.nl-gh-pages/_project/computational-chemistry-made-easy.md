---
contactPerson: /person/l.ridder
endorsedBy:
- /organization/nlesc
involvedOrganization:
- /organization/nlesc
- /organization/vua
logo: /images/project/computational-chemistry-made-easy.jpg
name: Computational Chemistry Made Easy
uses:
- /software/noodles
- /software/xenon
---

