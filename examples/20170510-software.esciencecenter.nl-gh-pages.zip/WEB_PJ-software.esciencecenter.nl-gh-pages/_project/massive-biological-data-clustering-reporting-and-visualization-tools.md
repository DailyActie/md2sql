---
competence:
- Big Data Analytics
contactPerson: /person/s.georgievska
discipline:
- Life Sciences & eHealth
expertise:
- Information Visualization
endorsedBy:
- /organization/nlesc
involvedOrganization:
- /organization/cbs-knaw
logo: /images/project/massive-biological-data-clustering-reporting-and-visualization-tools.jpg
name: Massive Biological Data Clustering, Reporting and Visualization Tools
nlescWebsite: https://www.esciencecenter.nl/project/massive-biological-data-clustering-reporting-and-visualization-tools
uses:
- /software/cclustera
---
A stepping stone for an online service for identification and classification of fungal species.
