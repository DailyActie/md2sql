---
competence:
- Big Data Analytics
contactPerson: /person/s.georgievska
coordinator: /person/e.ranguelova
dataFormat:
- JSON
dataMagnitude: GB
endDate: 2017-09-01
endorsedBy:
- /organization/nlesc
engineer:
- /person/s.georgievska
infrastructure: Computers Cluster
involvedOrganization:
- /organization/nlesc
- /organization/uva
name: ArenA
nlescWebsite: https://www.esciencecenter.nl/project/detecting-anomalous-behavior-in-stadium-crowds
principalInvestigator:
- affiliation:
  - /organization/uva
  name: Dr. Sander Klous
  website: https://nl.linkedin.com/in/sanderklous
startDate: 2015-09-01
tagLine: Detecting anomalous behaviour in stadium crowds using Wi-Fi positioning
---
