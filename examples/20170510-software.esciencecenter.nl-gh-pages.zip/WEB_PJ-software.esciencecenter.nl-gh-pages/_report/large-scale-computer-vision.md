---
title: Large Scale Computer Vision
link: /assets/report/content/LargeScaleComputerVision.pdf
cover: /assets/report/covers/LargeScaleComputerVision-cover.png
author:
- /person/e.ranguelova
date: 2015-08-12
---
The goal of this document is to present a focused partial overview of the state of the art in large
scale computer vision (CV).
