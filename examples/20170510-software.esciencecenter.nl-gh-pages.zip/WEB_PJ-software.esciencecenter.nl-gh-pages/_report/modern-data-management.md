---
title: Modern Data Management Solutions
link: /assets/report/content/Modern_Data_Management.pdf
cover: /assets/report/covers/Modern_Data_Management-cover.png
author:
- name: Milena Ivanova
date: 2014-07-08
---
This document comprises a short overview of modern data management technology.
