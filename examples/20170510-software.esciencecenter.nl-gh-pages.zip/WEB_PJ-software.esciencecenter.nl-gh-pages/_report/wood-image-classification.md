---
title: Wood Image Classification - Initial Results
link: /assets/report/content/WoodImageClassificationInitialResults.pdf
cover: /assets/report/covers/WoodImageClassificationInitialResults-cover.png
author:
- /person/e.ranguelova
date: 2016-05-26
---
This report gives some initial findings on how to automatically classify microscopy images of sections of wood species, given a set of annotated or labelled examples.
