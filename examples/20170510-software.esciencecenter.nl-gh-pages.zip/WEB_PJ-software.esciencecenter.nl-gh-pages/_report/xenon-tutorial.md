---
title: Tutorial - Distributed Computing with Xenon
link: /assets/report/content/xenon-tutorial.pdf
cover: /assets/report/covers/xenon-tutorial-cover.png
author:
- /person/j.spaaks
date: 2016-02-01
---
This document aims to help users without much prior knowledge about Java programming and without much experience in using remote systems to understand the basics of how to use the Xenon library.
