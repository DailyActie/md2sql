---
title: NLeSC Guide
link: https://nlesc.gitbooks.io/guide/content/
cover: /assets/report/covers/guide-cover.png
author:
- /organization/nlesc
date: 2016-08-29
---
A guide to projects and software developent at the Netherlands eScience Center. It both serves as a source of information for exactly how we work at NLeSC, and as a basis for discussions and reaching consensus on this topic.
This guide is a work in progress.
