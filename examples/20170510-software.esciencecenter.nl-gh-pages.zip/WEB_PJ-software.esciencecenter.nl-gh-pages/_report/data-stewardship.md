---
title: Data-Stewardship in the Big Data Era
link: /assets/report/content/DataStewardship_Final.pdf
cover: /assets/report/covers/data-stewardship.png
author:
- /organization/nlesc
date: 2013-01-01
---
The purpose of this document is to propose a series of actions to NWO as it formulates its policies on
data-stewardship.
