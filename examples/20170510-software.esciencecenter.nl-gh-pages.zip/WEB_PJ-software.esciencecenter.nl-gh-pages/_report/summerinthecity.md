---
title: Summer in the City
link: https://nlesc.gitbooks.io/summerinthecity/content/
cover: /assets/report/covers/summerinthecity-cover.png
author:
- /person/j.attema
date: 2016-03-01
---
This document forms the technical documentation for the Summer in the City project (ESOCCS12.013). The project is a collaboration between Wageningen University and the Netherlands eScience center. The project ran from 2013 to 2016.
