---
title: CERN ROOT conda recipes
link: https://nlesc.gitbooks.io/cern-root-conda-recipes/content/
cover: /assets/report/covers/root-conda-cover.png
author:
- /person/d.remenska
date: 2016-03-01
---
Conda recipes for building CERN ROOT binaries (with Python support) and its dependencies, to provide "pythonic" interface to the ROOT I/O format. It is an outcome of a pathfinder project is a collaboration between the XENON dark matter experiment and the Netherlands eScience center.
