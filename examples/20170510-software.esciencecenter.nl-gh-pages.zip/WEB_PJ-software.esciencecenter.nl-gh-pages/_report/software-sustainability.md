---
title: Research Software at the Heart of Discovery
link: /assets/report/content/Software_Sustainability_DANS_NLeSC_2016.pdf
cover: /assets/report/covers/software-sustainability.png
author:
- /organization/nlesc
- /organization/dans
date: 2016-02-16
---
This document sets out the need for increased attention to academic software-sustainability and
research software practice in general.
